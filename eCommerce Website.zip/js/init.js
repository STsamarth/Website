// Initialize products
if (!localStorage.getItem("products")) {
  const defaultProducts = [
    {
      title: "Stylish Watch",
      image: "images/watch.jpg",
      price: 1999,
      description: "A classy and stylish digital watch."
    },
    {
      title: "Bluetooth Headphones",
      image: "images/headphones.jpg",
      price: 2999,
      description: "High-quality sound and long battery life."
    },
    {
      title: "Smartphone Case",
      image: "images/case.jpg",
      price: 499,
      description: "Protective case for your smartphone."
    }
  ];
  localStorage.setItem("products", JSON.stringify(defaultProducts));
}

// Initialize orders
if (!localStorage.getItem("orders")) {
  localStorage.setItem("orders", JSON.stringify([]));
}

// Initialize feedbacks
if (!localStorage.getItem("feedbacks")) {
  localStorage.setItem("feedbacks", JSON.stringify([]));
}

// Admin login details (stored in memory only, not localStorage)
const adminUsername = "admin";
const adminPassword = "1234";

// Utility to load data
function getData(key) {
  return JSON.parse(localStorage.getItem(key)) || [];
}

// Utility to save data
function saveData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}