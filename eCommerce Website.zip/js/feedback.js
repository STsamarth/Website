document.getElementById("feedback-form").addEventListener("submit", function(e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();

  if (!name || !email || !message) {
    alert("Please fill all fields.");
    return;
  }

  const feedback = {
    name,
    email,
    message,
    date: new Date().toLocaleString()
  };

  const allFeedback = JSON.parse(localStorage.getItem("feedback")) || [];
  allFeedback.push(feedback);
  localStorage.setItem("feedback", JSON.stringify(allFeedback));

  alert("Thank you for your feedback!");
  this.reset();
});