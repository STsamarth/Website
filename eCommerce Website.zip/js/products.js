document.addEventListener("DOMContentLoaded", () => {
  const productContainer = document.getElementById("product-detail");
  const urlParams = new URLSearchParams(window.location.search);
  const productId = parseInt(urlParams.get("id"));

  fetch("data/products.json")
    .then(res => res.json())
    .then(products => {
      const product = products.find(p => p.id === productId);

      if (product) {
        productContainer.innerHTML = `
          <img src="${product.image}" alt="${product.name}" />
          <h2>${product.name}</h2>
          <p><strong>Price:</strong> ₹${product.price}</p>
          <p>${product.description}</p>
          <button onclick="addToCart(${product.id})">Add to Cart</button>
        `;
      } else {
        productContainer.innerHTML = "<p>Product not found.</p>";
      }
    });
});

function addToCart(id) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push(id);
  localStorage.setItem("cart", JSON.stringify(cart));
  alert("Product added to cart!");
}