document.addEventListener("DOMContentLoaded", () => {
  const summaryDiv = document.getElementById("order-summary");
  const orders = JSON.parse(localStorage.getItem("orders")) || [];

  if (orders.length === 0) {
    summaryDiv.innerHTML = "<p>No order found.</p>";
    return;
  }

  const lastOrder = orders[orders.length - 1];
  const { name, phone, address, date } = lastOrder;

  let summaryHtml = `
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Phone:</strong> ${phone}</p>
    <p><strong>Address:</strong> ${address}</p>
    <p><strong>Order Date:</strong> ${date}</p>
    <p><strong>Items:</strong> ${lastOrder.items.length} products</p>
  `;

  summaryDiv.innerHTML = summaryHtml;
});