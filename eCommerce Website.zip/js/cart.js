document.addEventListener("DOMContentLoaded", () => {
  const cartContainer = document.getElementById("cart-items");
  const cart = JSON.parse(localStorage.getItem("cart")) || [];

  fetch("data/products.json")
    .then(res => res.json())
    .then(products => {
      if (cart.length === 0) {
        cartContainer.innerHTML = "<p>Your cart is empty.</p>";
        return;
      }

      let total = 0;

      cart.forEach(id => {
        const product = products.find(p => p.id === id);
        if (product) {
          total += product.price;
          const item = document.createElement("div");
          item.className = "cart-item";

          item.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <div class="info">
              <h4>${product.name}</h4>
              <p>₹${product.price}</p>
            </div>
            <button onclick="removeFromCart(${product.id})">Remove</button>
          `;

          cartContainer.appendChild(item);
        }
      });

      const totalDiv = document.createElement("div");
      totalDiv.innerHTML = `<h3>Total: ₹${total}</h3>`;
      cartContainer.appendChild(totalDiv);
    });

  document.getElementById("orderForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const address = document.getElementById("address").value.trim();

    if (!name || !phone || !address) {
      alert("Please fill all fields.");
      return;
    }

    const order = {
      name,
      phone,
      address,
      items: cart,
      date: new Date().toLocaleString()
    };

    // Simulated order saving
    let orders = JSON.parse(localStorage.getItem("orders")) || [];
    orders.push(order);
    localStorage.setItem("orders", JSON.stringify(orders));

    alert("Order placed successfully! (Cash on Delivery)");
    localStorage.removeItem("cart");
    window.location.href = "index.html";
  });
});

function removeFromCart(id) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart = cart.filter(item => item !== id);
  localStorage.setItem("cart", JSON.stringify(cart));
  location.reload();
}