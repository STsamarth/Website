// Protect Admin Panel
if (localStorage.getItem("adminLoggedIn") !== "true") {
  alert("Access denied. Please login as admin.");
  window.location.href = "admin-login.html";
}

// Get Products
function getProducts() {
  return JSON.parse(localStorage.getItem("products")) || [];
}

// Save Products
function saveProducts(products) {
  localStorage.setItem("products", JSON.stringify(products));
}

// Render Products
function renderProducts() {
  const productList = document.getElementById("product-list");
  const products = getProducts();
  productList.innerHTML = "";

  products.forEach((product, index) => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <img src="${product.image}" alt="${product.title}" />
      <h3>${product.title}</h3>
      <p>${product.description}</p>
      <p><strong>₹${product.price}</strong></p>
      <button class="remove-btn" onclick="removeProduct(${index})">Remove</button>
    `;
    productList.appendChild(card);
  });
}

// Add Product
document.getElementById("add-product-form").addEventListener("submit", function(e) {
  e.preventDefault();

  const title = document.getElementById("new-title").value;
  const image = document.getElementById("new-image").value;
  const price = document.getElementById("new-price").value;
  const description = document.getElementById("new-desc").value;

  const newProduct = { title, image, price, description };

  const products = getProducts();
  products.push(newProduct);
  saveProducts(products);

  this.reset();
  renderProducts();
  alert("Product added successfully!");
});

// Remove Product
function removeProduct(index) {
  const products = getProducts();
  products.splice(index, 1);
  saveProducts(products);
  renderProducts();
}

// Logout Admin
function logout() {
  localStorage.removeItem("adminLoggedIn");
  window.location.href = "admin-login.html";
}

renderProducts();