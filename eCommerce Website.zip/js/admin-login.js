document.getElementById("admin-login-form").addEventListener("submit", function(e) {
  e.preventDefault();

  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const errorMsg = document.getElementById("error-msg");

  // Set your admin credentials here
  const adminUsername = "admin";
  const adminPassword = "1234";

  if (username === adminUsername && password === adminPassword) {
    localStorage.setItem("adminLoggedIn", "true");
    window.location.href = "admin-panel.html";
  } else {
    errorMsg.textContent = "Invalid username or password!";
  }
});